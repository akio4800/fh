#include <functional>



namespace fn {
	double integrate_serial(std::function<double(double)> func_integratee, std::function<double(double)> func_integrate) {
	}
	
		double integrate_parallel() {




	}







}